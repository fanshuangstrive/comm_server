#include "wrapunix.h"


#ifndef	TRUE
#define	TRUE	1
#define	FALSE	0
#endif
int setnbio( int fd, int flg )
{
	int		optval;

	if ( flg == TRUE ) 
		optval = 1;
	else
		optval = 0;

	if ( ioctl( fd, FIONBIO, &optval ) == -1 ) {
		CommLog(LOG ,  "[%s][%d]ioctl() error,[%s]" ,__FILE__,__LINE__,strerror(errno));
		return -1;
	}
	  
	return 0;
}
int send_nbytes( int sock, void *buf, int len )
{
    int left=len, cnt, sended=0;
	
    setnbio( sock, FALSE );
    while ( left > 0 ) {
        errno = 0;
        if ( ( cnt = send( sock, buf+sended, left, 0 ) ) < 0 ) {
			     if ( errno == EINTR ){
				      continue;
		       }
           CommLog(LOG ,  "[%s][%d]send() error,[%s]" ,__FILE__,__LINE__,strerror(errno));
           return -1;
        }
        left   -= cnt;
        sended += cnt;
    }

	return sended;
}


int recvn(int fd , void * vptr , size_t n)
{
    ssize_t nleft;
    ssize_t nread;
    char    *ptr;

    ptr = vptr;
    nleft = n ;
    while(nleft > 0){
        if((nread = recv(fd , ptr , nleft,0)) < 0){
            if(errno == EINTR)
                nread = 0;
            else
                return(-1);
        }else if (nread == 0)
            break;
        nleft -= nread;
        ptr += nread;
    }
    return(n - nleft);
}
int  tcp_listener( int *sockid,unsigned long _addr,unsigned short   _port )
{
    struct      sockaddr_in s_addr_in;
#if 0
    struct      linger linger;
#endif
    int         _sockid;
    int         optval=1;

	if ( (_sockid=socket( AF_INET, SOCK_STREAM, 0 )) == -1 ) {
		CommLog(LOG ,   "[%s][%d]socket() error,[%s]" ,__FILE__,__LINE__,strerror(errno));
		return -1;
	}

	memset( &s_addr_in, 0x0, sizeof( s_addr_in ) );

	s_addr_in.sin_family      = AF_INET;
	s_addr_in.sin_port        = htons( _port );
	s_addr_in.sin_addr.s_addr = _addr;

	setsockopt( _sockid, SOL_SOCKET, SO_REUSEADDR, &optval, sizeof(int) );

#if 0
	linger.l_onoff  = 1;
	linger.l_linger = 10;
	setsockopt( _sockid, SOL_SOCKET, SO_LINGER, &linger, sizeof(linger) );
#endif

	if ( bind( _sockid, (void *)&s_addr_in, sizeof( s_addr_in ) ) == -1 ) {
        CommLog(LOG ,  "[%s][%d]bind() error,[%s]" ,__FILE__,__LINE__,strerror(errno));
        sock_close( _sockid );
        return -1;
    }

    if ( listen( _sockid, SOMAXCONN ) == -1 ) {
        CommLog(LOG ,  "[%s][%d]listen() error,[%s]" ,__FILE__,__LINE__,strerror(errno));
        sock_close( _sockid );
        return -1;
    }

    /* ����exec���ӽ��̣�����fd�Զ��ر� */
    fcntl( _sockid, F_SETFD, 1 );
    *sockid = _sockid;

	return 0;
}
int  tcp_accept( int sock, unsigned long  *_peeraddr, unsigned short *_peerport )
{
	int		new_sock;
	struct	sockaddr_in peeraddr_in;
	unsigned int   	addr_len;

	addr_len = sizeof( struct sockaddr_in );
	memset( &peeraddr_in, 0x00, addr_len );

	for ( ; ; ) {   /* Loop if interrupted by signal */
		errno = 0;
		if ( ( new_sock = accept( sock, (void *)&peeraddr_in,&addr_len )) == -1 ) {
             if ( errno == EINTR )
                 continue;
              CommLog(LOG ,  "[%s][%d]accept() error,[%s]" ,__FILE__,__LINE__,strerror(errno));
             return -1;
        }
        break;
    }

    *_peeraddr = peeraddr_in.sin_addr.s_addr;
    *_peerport = peeraddr_in.sin_port;

    return( new_sock );
}


/**********ȡ���ض˿ں�**************/
int  get_local_port(int socket,u_short *port){
  	
  struct sockaddr_in sa_in;
  u_int  len ;
  int    ret ;
  
  memset(&sa_in,0x00,sizeof(struct sockaddr_in));
  len = sizeof(sa_in) ;
  
  ret = getsockname(socket, (struct sockaddr *)&sa_in, &len);
  if( ret < 0){
      CommLog( LOG, "FILE [%s] line %d getsockname error [%s]",__FILE__,__LINE__ ,strerror(errno));
      return E_FAIL ;
  }
  *port = ntohs(sa_in.sin_port);

   return E_OK ;
}
  
  
  
int sock_close( int sock )
{
	return close( sock );
}
