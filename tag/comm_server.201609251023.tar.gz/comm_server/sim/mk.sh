buildclient -o tux_cli -f "tux_cli.c"
