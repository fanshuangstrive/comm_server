. ./tux.env

tmshutdown -y
tmloadcf  ubbsimple.wsl -y
