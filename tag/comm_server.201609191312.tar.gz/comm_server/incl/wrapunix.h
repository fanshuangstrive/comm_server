#ifndef __WRAP_UNIX_H
#define __WRAP_UNIX_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdarg.h>
#include <sys/time.h>
#include <time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <setjmp.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <atmi.h>

#define LOG "log/comm.log"
#define E_OK 0
#define E_FAIL -1

#define RESPCODE_OK "0"
#define RESPCODE_TIMEOUT "1"
#define RESPCODE_TUXEDO_ERR "2"

#define CFG_FILENAME  "etc/comm_server.cfg"
#define TIMEOUT 60 /*��ʱʱ��*/
#define PKGHEAD_LENGTH 8 /*���ĸ�ʽ��8λ����PKGHEAD_LENGTH(����ʱ����)$Tuxedo������$���ݰ�*/
#define MAXBUF_LEN 10240
#define MAX_LINE_LEGTH 4096


#endif

